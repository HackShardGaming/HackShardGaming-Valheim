Welcome to HackShardGaming!

The following files will allow you to connect to the HackShardGaming Valheim Plus Server!


Patch Notes

HsG V0.4	Date: 2/28/2021		Valheim Version: 0.146.11@0.9
>>	Added multiple new plugins
>>	Any Portal (Allows us to select where to port us to by selecting it from a list of availble portals.)
>>	BetterUI (Adds a new UI element to the game. including Health Amount on mobs and Stars instead of numbers for equip levels.)
>>	HostName Connect (Not only will this allow us to connect to our server using its hostname but it will save the previous servers.)
>>	Quick Connect (We made a list of available servers which ofc are ours!)

HsG V0.3.4	Date: 2/27/2021		Valheim Version: 0.146.11@0.9
>>	Patched a bug involving BetterDiscordPresence. It's dlls needed to be in a BetterDiscordPresence folder inside the plugins folder.


HsG V0.3.3	Date: 2/27/2021		Valheim Version: 0.146.11@0.9
>> 	Plugin Added: Server Side Maps!

HsG V0.3.2	Date: 2/27/2021		Valheim Version: 0.146.11@0.9
>> 	Once again: Updated all base plugins...

HsG V0.3	Date: 2/26/2021		Valheim Version: 0.146.11@0.9
>>	Updated all base plugins.

HsG V0.2	Date: 2/26/2021 	Valheim Version: 0.146.8@0.9
>>	Added Additional Plugins
>>	Plugin Added: NexusUpdate (Shows all installed plugins and if an update is currently available via nexusmods.com)
>>	Plugin Added: BetterDiscordPresence (makes your presence in discord more informational)
>>	Plugin Added: discord-rpc (Plugin for BetterDiscordPresence)
>>	Plugin Added: EquipmentAndQuickSlots (Added 8 additional item slots. including 3 hotkeys and "Equipment" slots.)
>> 	Included in this latest patch is a new PowerShell script named Plugin_Enabler.ps1  This file will allow you to
>>	Enable or Disable all mods installed by this pack or elsewhere.  Enabling you to quickly switch between "Classic"
>>	and "Valheim Plus"

HsG V0.1	Date: 2/25/2021 	Valheim Version: 0.146.8@0.9
>>	Initial Release.
>>	Plugin Added: Valheim Plus
